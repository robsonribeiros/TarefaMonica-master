package com.MatrizDeConhecimento.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.MatrizDeConhecimento.ApiService.ApiService;
import com.MatrizDeConhecimento.Models.Colaborador;
import com.MatrizDeConhecimento.Models.MatrizDeConhecimento;


@RestController 
public class Controller {

	@Autowired
	private ApiService colaboradorService;
	
	@GetMapping("/colaborador/{cpf}")
	public  ResponseEntity<?> BuscaColaborador(@PathVariable(value = "cpf")String cpf){
		Colaborador colaborador = new Colaborador();
		colaborador = colaboradorService.BuscaColaborador(cpf);
		if(colaborador == null) {
			return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Colaborador não encontrado");
		}
		else {
			return ResponseEntity.status(HttpStatus.OK).body(colaborador);
		}
	}
	@GetMapping("/colaborador/busca/{competencia}")
	public ResponseEntity<String> BuscaCompetencia(@PathVariable(value = "competencia") String competencia){
		
		return colaboradorService.BuscaCompetencia(competencia);
	}
	@GetMapping("/colabs")
	public ResponseEntity<List<Colaborador>> testeApi(){
		return ResponseEntity.status(HttpStatus.OK).body(colaboradorService.Buscatodos());
	}
	

	@PostMapping("/competencia/{cpf}")
	public ResponseEntity<String>addCompColaboradores(@PathVariable("cpf")String cpf,@RequestBody MatrizDeConhecimento matrizDeConhecimento){
		colaboradorService.addCompColaboradores(matrizDeConhecimento,cpf);
		return ResponseEntity.status(HttpStatus.OK).body("");
	}
	
}

