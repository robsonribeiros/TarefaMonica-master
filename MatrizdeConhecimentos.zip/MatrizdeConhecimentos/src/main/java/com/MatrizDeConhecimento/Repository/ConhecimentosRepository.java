package com.MatrizDeConhecimento.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.MatrizDeConhecimento.Models.MatrizDeConhecimento;

public interface ConhecimentosRepository extends JpaRepository<MatrizDeConhecimento,String> {

}
