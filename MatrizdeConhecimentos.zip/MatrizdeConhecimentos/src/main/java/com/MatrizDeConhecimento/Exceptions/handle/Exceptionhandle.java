package com.MatrizDeConhecimento.Exceptions.handle;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import com.MatrizDeConhecimento.Exceptions.ColaboradorInexistenteException;

@RestControllerAdvice
public class Exceptionhandle {

	public ResponseEntity<Object>handleCPFDontExistentsException(ColaboradorInexistenteException e){
		return ResponseEntity.status(HttpStatus.NOT_FOUND).body(e.getMessage());
	}
}
