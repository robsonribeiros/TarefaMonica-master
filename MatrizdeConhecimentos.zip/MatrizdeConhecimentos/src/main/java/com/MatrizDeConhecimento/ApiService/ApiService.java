package com.MatrizDeConhecimento.ApiService;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.MatrizDeConhecimento.Exceptions.ColaboradorInexistenteException;
import com.MatrizDeConhecimento.Models.Colaborador;
import com.MatrizDeConhecimento.Models.MatrizDeConhecimento;
import com.MatrizDeConhecimento.Models.MatrizDeConhecimentoColaborador;
import com.MatrizDeConhecimento.Repository.ConhecimentosRepository;
import com.MatrizDeConhecimento.feing.APIdeColaboradores;

@Service
public class ApiService {

	@Autowired 
	private APIdeColaboradores apiDeColaboradores;
	@Autowired
	private ConhecimentosRepository conhecimentosRepository;

	public void addCompColaboradores(MatrizDeConhecimento matrizDeConhecimento, String cpf) {
		Colaborador colaborador =  new Colaborador();
		colaborador = BuscaColaborador(cpf);
		MatrizDeConhecimentoColaborador colaboradorCompleto = new MatrizDeConhecimentoColaborador();
		colaboradorCompleto.setCpf(colaborador.getCpf());
		colaboradorCompleto.setNome(colaborador.getNome());
		colaboradorCompleto.setCargo(colaborador.getCargo());
		colaboradorCompleto.setSede(colaborador.getSede());
		colaboradorCompleto.setData_de_nascimento(colaborador.getData_de_nascimento());
		colaboradorCompleto.setData_de_admissao(colaborador.getData_de_admissao());
		
		conhecimentosRepository.save(matrizDeConhecimento);
	}

	public Colaborador BuscaColaborador(String cpf) {
		
		List<Colaborador> listColaborador = new ArrayList<>();
		listColaborador = apiDeColaboradores.GetColaboradores();
		Colaborador colaborador = new Colaborador();
		for(Colaborador colaboradores:listColaborador) {
			if(colaboradores.getCpf().equalsIgnoreCase(cpf)) {
				colaborador = colaboradores;  
			}
		}
		if(colaborador != null) {
			return colaborador;
		}
		else {
			
			throw new ColaboradorInexistenteException("Colaborador não encontrado");
		}
	}

	public ResponseEntity<String> BuscaCompetencia(String competencia) {
		List<Colaborador>listCompetencia = new ArrayList<>();
		listCompetencia = apiDeColaboradores.GetColaboradores();
		Colaborador colaborador = new Colaborador();
		for(Colaborador colaboradores:listCompetencia) {
			
		}
		return null;
	}

	public List<Colaborador> Buscatodos() {
		
		return apiDeColaboradores.GetColaboradores();
	}

}
