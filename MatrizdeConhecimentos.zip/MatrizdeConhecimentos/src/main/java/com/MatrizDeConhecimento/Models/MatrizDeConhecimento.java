package com.MatrizDeConhecimento.Models;

public class MatrizDeConhecimento {

	private String competencia;
	private String experiencia;
	
	public String getCompetencia() {
		return competencia;
	}
	public void setCompetencia(String competencia) {
		this.competencia = competencia;
	}
	public String getExperiencia() {
		return experiencia;
	}
	public void setExperiencia(String experiencia) {
		this.experiencia = experiencia;
	}
}
