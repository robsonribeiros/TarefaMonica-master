CREATE TABLE matconhecimento(
cpf					VARCHAR(255) PRIMARY KEY	NOT NULL,
nome				VARCHAR(255) NOT NULL,
cargo 				VARCHAR(255) NOT NULL,
sede				VARCHAR(255) NOT NULL,
data_de_nascimento 	DATE 		 NOT NULL,
data_de_admissao  	DATE 		 NOT NULL,
competencia			VARCHAR(255) NOT NULL,
experiencia 		VARCHAR(255) NOT NULL
);